# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

## [Known Issues]
- Please submit issues via [GitHub](https://github.com/maxdorx/MeshCentral-ScriptTask/issues).

## [1.0.11] - 2026-11-23
### Added
- Group schedules in Deployments, with per-device results and controls to pause, resume, edit schedules, and retry failed devices.
- Inspect all visible unfinished jobs in Queue, including older records. Cancel waiting jobs or stop retrying dispatched jobs.
- Set an optional expiration for Run now jobs that have not been sent.

## [1.0.10] - 2026-11-23
### Added
- Select individual schedules or all schedules shown and delete them together.
- Clear all selected devices in the Run tab, including devices hidden by filters.

### Fixed
- Keep the Select visible device checkbox in sync with the current selection.

## [1.0.9] - 2026-10-23
### Fixed
- Allow scripts stored directly in Shared to be renamed and deleted.
- Restrict root protection to the Shared folder itself instead of every item whose path is Shared.

## [1.0.8] - 2026-10-23
### Fixed
- Use a stable installer URL because MeshCentral retains the download URL from the currently installed plugin record during upgrades.
- Refresh the 1.0.4 through 1.0.7 installer aliases with the current package so installations using the earlier version-specific URLs can upgrade in place.
- Preserve plugin data and history by repairing the normal Upgrade path without requiring an uninstall.

## [1.0.7] - 2026-10-23
### Fixed
- Wait for MeshCentral's browser connection to become ready before requesting dashboard data or sending actions.
- Retry connection-dependent requests instead of leaving the script library stuck on Loading.
- Namespace the dialog container so MeshCentral and Bootstrap modal styles cannot hide ScriptTask dialogs.

## [1.0.6] - 2026-10-22
### Improved
- Compact the selected-script header and primary navigation to preserve working space.
- Combine device search, group, online, selection, and count controls into one toolbar.
- Let the device list fill the available panel height and reduce row padding for denser fleet views.
- Show more result rows in the available space without changing output detail or retention.

## [1.0.5] - 2026-10-22
### Fixed
- Keep desktop scrolling inside the plugin panels so the toolbar and MeshCentral heading remain visible.
- Paginate result history with 25, 50, or 100 rows per page and show newest activity first.
- Collapse long command output by default while keeping a useful result summary visible.

## [1.0.4] - 2026-10-22
### Fixed
- Use a version-specific installer ZIP so GitHub's raw-file cache cannot serve an older plugin build for a newer manifest.

## [1.0.3] - 2026-10-22
### Fixed
- Synchronize the embedded interface with MeshCentral's active theme stylesheet and Bootstrap color variables.
- Follow live theme changes for backgrounds, panels, controls, borders, text, status colors, and accent contrast.
- Use the parent MeshCentral font and retain standalone colors only as compatibility fallbacks.

## [1.0.2] - 2026-10-22
### Fixed
- Remove the duplicate in-page ScriptTask heading and normalize the host heading size.
- Preserve keyboard focus and caret position while filtering devices or results.
- Require a script selection before showing or exporting result history.

## [1.0.1] - 2026-10-22
### Fixed
- Match the proven MeshCentral Inventory plugin manifest and release-package format.
- Use MeshCentral's shared server-plugin page for the top-level ScriptTask tab.
- Allow the server plugin page to render through `goPlugin` without the legacy per-device query parameter.
- Declare the tested MeshCentral 1.2.5 compatibility floor and provide an installer-ready ZIP.

## [1.0.0] - 2026-10-22
### Added
- A standalone top-level ScriptTask workspace instead of a per-device plugin tab.
- Fleet device selection with search, device-group filtering, online filtering, Run Now, and scheduling.
- Unified results, schedules, variables, JSON output formatting, and server-generated CSV export.
- Responsive light/dark UI and in-page dialogs compatible with MeshCentral 1.3.0.
- MeshCentral plugin permissions for viewing, running, editing, and variable management.
- Domain scoping and server-side validation of target-device rights.

### Fixed
- Legacy dialogs that no longer opened on current MeshCentral releases.
- Duplicate schedule query conditions, single-node schedule creation, Bash normalization, and duplicate NeDB callbacks.
- Script download path validation and agent job/script validation.

## [0.0.20] - 2025-01-08
### Fixed
- Merge PR fixing MeshCentral 1.1.35+ compatibility

## [0.0.19] - 2024-02-07
### Fixed
- Merge PR fixing scroll bars and Powershell execution policy

## [0.0.18] - 2022-03-12
### Fixed
- Compatibility with MeshCentral => 0.9.98 (promise requirement removed from MeshCentral, nedb moved to @yetzt/nedb)

## [0.0.17] - 2021-10-07
### Fixed
- Compatibility with MeshCentral > 0.9.7

## [0.0.16] - 2021-05-18
### Fixed
- Drag/drop scripts between folders

## [0.0.15] - 2020-03-07
### Fixed
- Prevent race condition with conflicting plugins changing the app views directory by using absolute paths

## [0.0.14] - 2020-02-28
### Added
- Add new script from ScriptTask plugin without dragging/uploading an existing script
- Variables introduced. Supports global, script, mesh, and node level. Overridden in that order.

## [0.0.13] - 2020-02-15
### Fixed
- Folder rename function now working as intended
- Removed ability to "edit" folders as if they were a script

## [0.0.12] - 2020-02-14
### Fixed
- Rename function broke when filetype tags were added

## [0.0.11] - 2020-01-24
### Added
- Advanced selection of nodes based on mesh and tag membership

## [0.0.10] - 2020-01-02
### Fixed
- Removed logging to MeshCentral events DB for each script run / refresh event (causing events file to grow quickly and crash NeDB instances)

## [0.0.9] - 2019-12-24
### Fixed
- Native Powershell scripts now run correctly on more versions of Linux/MacOS

## [0.0.8] - 2019-12-23
### Fixed
- Force strip carriage returns from bash scripts

## [0.0.7] - 2019-12-23
### Fixed
- Some versions of Linux don't default the agents root to the MeshAgent's directory. Added path detection for a safe temp zone. Thanks /u/Reverent for the assist in debugging that one!

## [0.0.6] - 2019-12-23
### Added
- Status return of a script as success/failure if the script does not produce output
- Endpoint debugging toggle via console (plugin scripttask debug)
### Fixed
- Made some endpoint calls a little safer with try/catch to stop errors from killing the process

## [0.0.5] - 2019-12-22
### Added
- NeDB support
### Fixed
- CSS call looking for mapping file removed
- Date/time select on schedule screen might not have had the correct mimetype, thus not appeared in some instances

## [0.0.4] - 2019-12-22
### Added
- Script type identifier to the script tree view
### Fixed
- Prevent catch-up jobs from running every minute on long running schedules when a node is offline for a period of time.
- Check for scheduled jobs 1 minute in the future to prevent schedules running 1 minute behind intended time.

## [0.0.3] - 2019-12-20
### Fixed
- Typo causing installs to think Mongo is not in use

## [0.0.2] - 2019-12-20
### Added
- Suppressed errors and made a nice error message for those without MongoDB (currently unsupported)

## [0.0.1] - 2019-12-20
### Added
- Released initial version
